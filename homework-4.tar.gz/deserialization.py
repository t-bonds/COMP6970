from exceptions import DeserializationError
import re


def __unmarshal_string(marshalled_string):
    ret = ""

    reserved_dict = {"%21": "!", "%22": "#", "%23": "$", "%25": "%", "%26": "&", "%27": "'",
                     "%28": "(", "%29": ")", "%2A": "*", "%2B": "+", "%2C": ",", "%2F": "/", "%3A": ":", "%3B": ";", "%3D": "=", "%3F": "?", "%40": "@", "%5B": "[", "%5D": "]"}

    if marshalled_string[-1] == "s":
        ret = marshalled_string[:-1]
        return ret
    str_value = ''
    for char in marshalled_string:

        if char == "%":
            index = marshalled_string.index(char)
            str_value = marshalled_string[index +
                                          1] + marshalled_string[index + 2]
            str = "%" + str_value
            if str in reserved_dict:
                ret += reserved_dict[str]

        else:
            ret += char

    ret = ret.replace(str_value, "")
    return ret


def __unmarshal_integer(marshalled_integer):
    ret = 0

    marshalled_integer = marshalled_integer[1:]
    ret = int(marshalled_integer)

    return ret


def __unmarshal_map(marshalled_map):
    ret = {}

    if marshalled_map == '{}':
        return ret

    marshalled_map = marshalled_map[1:]
    marshalled_map = marshalled_map[:-1]

    if "," in marshalled_map:
        str_list = marshalled_map.split(",")
        for sub_str in str_list:
            str_index = sub_str.split(":")
            value = str_index[1]
            if 'i' in value[0]:
                ret[str_index[0]] = __unmarshal_integer(str_index[1])
            elif '}' in value[-1]:
                ret[str_index[0]] = __unmarshal_map(str_index[1])
            else:
                ret[str_index[0]] = __unmarshal_string(str_index[1])
    else:
        str_list = marshalled_map.split(":", 1)
        value = str_list[1]
        if 'i' in value[0]:
            ret[str_list[0]] = __unmarshal_integer(str_list[1])
        elif '}' in value[-1]:
            ret[str_list[0]] = __unmarshal_map(str_list[1])
        else:
            ret[str_list[0]] = __unmarshal_string(str_list[1])
    return ret


def unmarshal(marshalled_state):
    if marshalled_state is None:
        raise DeserializationError("Input is None")
    if type(marshalled_state) != str:
        raise DeserializationError("Input is not a string")
    if not all(ord(c) < 128 for c in marshalled_state):
        raise DeserializationError("Input is not ASCII.")

    return __unmarshal_map(marshalled_state)
