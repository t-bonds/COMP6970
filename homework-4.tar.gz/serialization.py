from exceptions import SerializationError
import re


def __marshal_string(py_string):
    ret = ""
    complex = False
    skip = False
    reserved_dict = {"!": "%21", "#": "%22", "$": "%23", "%": "%25", "&":       "%26", "'": "%27",
                     "(": "%28", ")": "%29", "*": "%2A", "+": "%2B", ",": "%2C", "/": "%2F", ":": "%3A", ";": "%3B", "=": "%3D", "?": "%3F", "@": "%40", "[": "%5B", "]": "%5D"}

    for char in py_string:
        if char in reserved_dict:
            complex = True
            ret += reserved_dict[char]
        else:
            ret += char
    if not complex:
        ret = py_string + "s"
    return ret


def __marshal_integer(py_int):
    ret = ""

    ret = "i" + str(py_int)

    return ret


def __marshal_map(py_dict):
    ret = "{"
    r_full = re.compile("\\w|" "|.-_+\\.]")

    if py_dict == {}:
        ret += "}"
        return ret

    for key, value in py_dict.items():

        for letter in key:
            if not re.match(r_full, letter):
                raise SerializationError(
                    "Error: " + letter + " is not supported.")
        if isinstance(value, int):
            value = __marshal_integer(value)
            ret += str(key) + ":" + value
            if len(py_dict) > 1:
                ret += ","
        elif isinstance(value, str):
            value = __marshal_string(value)
            ret += str(key) + ":" + value
            if len(py_dict) > 1:
                ret += ","
        elif isinstance(value, dict):
            value = __marshal_map(value)
            ret += str(key) + ":" + value
            if len(py_dict) > 1:
                ret += ","
    if ret[-1] == ",":
        ret = ret[:-1]

    ret += "}"
    return ret


def marshal(unmarshalled_state):
    if unmarshalled_state is None:
        raise SerializationError("Input is None")
    if type(unmarshalled_state) != dict:
        raise SerializationError("Input is not a dict")

    temp_list = []
    for key in unmarshalled_state:
        if len(temp_list) == 0:
            temp_list.append(key)
            continue
        if len(temp_list) == 1:
            temp_list.append(key)
            continue
        if key in temp_list:
            raise SerializationError("Dictionary cannot have duplicate keys.")
        else:
            temp_list.append(key)

    for key in unmarshalled_state:
        if type(key) == dict:
            raise SerializationError(
                "Keys in the dictionary cannot also be dictionaries.")

    return __marshal_map(unmarshalled_state)
